## ---- echo = FALSE, message=FALSE---------------------------------------------
library(knitr)
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
library("RSoptSC")
set.seed(13)

## ---- results='asis'----------------------------------------------------------
df <- system.file("extdata", "GSE67602_JoostData.csv.bz2", package = "RSoptSC")
gf <- system.file("extdata", "GSE67602_JoostGenes.csv.bz2", package = "RSoptSC")
cf <- system.file("extdata", "GSE67602_JoostCells.csv.bz2", package = "RSoptSC")
af <- system.file("extdata", "GSE67602_JoostAnnotation.csv.bz2", package = "RSoptSC")

GSE67602_Joost <- LoadData(df, gf, cf, af)

## ---- results='asis'----------------------------------------------------------
gene_names <- GSE67602_Joost$gene_names
spikein <- grep('ERCC', gene_names)
gene_names <- gene_names[-spikein]
data <- GSE67602_Joost$data[-spikein,]

## ---- results='asis'----------------------------------------------------------
logdata <- log10(data + 1)
gene_expression_threshold <- 0.03
n_features <- 3000
filtered_data <- SelectData(logdata, gene_expression_threshold, n_features)

## ---- results='asis', results='hide'------------------------------------------
S <- SimilarityM(lambda = 0.05, 
                 data = filtered_data$M_variable,
                 dims = 3,
                 pre_embed_method = 'tsne',
                 perplexity = 20, 
                 pca_center = TRUE, 
                 pca_scale = TRUE)

## ---- results='asis'----------------------------------------------------------
low_dim_mapping <- RepresentationMap(similarity_matrix = S$W,
                                      flat_embedding_method = 'tsne',
                                      join_components = TRUE,
                                      perplexity = 35,
                                      theta = 0.5,
                                      normalize = FALSE,
                                      pca = TRUE,
                                      pca_center = TRUE,
                                      pca_scale = TRUE,
                                      dims = 2,
                                      initial_dims = 2)

## ---- results='asis', message=FALSE, warning=FALSE----------------------------
clusters <- ClusterCells(similarityMatrix = S$W, n_comp = 15, .options='p')
H <- clusters$H
labels <- clusters$labels
n_clusters <- length(unique(clusters$labels))

plot(c(1:20), 
     clusters$ensemble$eigs$val[1:20],
     xlab = NA,
     ylab = 'eigenvalues',
     main = 'Eigenvalues of the Graph Laplacian')

## ---- results='asis'----------------------------------------------------------
# define a scheme for the coloring.  This is a required parameter for plotting discrete (factor) data
colorscale <- ColorHue(n = length(unique(labels)))
colorscale <- colorscale$hex.1.n.

# plot clusters
FeatureScatterPlot(flat_embedding = low_dim_mapping$flat_embedding,
                         feature = as.factor(labels),
                         title = "NMF Cluster Labeling",
                         subtitle = "t-SNE Embedding",
                         featurename = "Cluster ID",
                         colorscale = colorscale)

## ---- results='asis'----------------------------------------------------------
true_labels <- GSE67602_Joost$annotation
# plot clusters
FeatureScatterPlot(flat_embedding = low_dim_mapping$flat_embedding,
                         feature = as.factor(true_labels),
                         title = "True Labeling",
                         subtitle = "t-SNE Embedding",
                         featurename = "Annotated Cell Types")

## ---- fig.width=7, fig.height=9-----------------------------------------------
markers <- GetMarkerTable(counts_data = logdata,
                            cluster_labels = labels,
                            H = H,
                            n_sorted = 25)

PlotTopN_Grid(data = logdata,
              cluster_labels = labels,
              markers = markers$all,
              n_features = 15)

## ---- results='asis'----------------------------------------------------------
cluster_ptime <- FindRootCluster(cluster_labels = labels,
                                 flat_embedding = low_dim_mapping$flat_embedding,
                                 dist_graph = low_dim_mapping$dist_graph,
                                 dist_flat = low_dim_mapping$dist_flat,
                                 reverse = TRUE)

## ---- results='asis'----------------------------------------------------------
root_cell <- FindRootCell(use_flat_dist = FALSE,
                          cluster_order_by = "distance",
                          cell_order_by = "distance",
                          graph_cluster_mst = cluster_ptime$cluster_mst,
                          dist_graph  = low_dim_mapping$dist_graph,
                          dist_flat = low_dim_mapping$dist_flat,
                          cluster_labels = labels,
                          root_cluster = cluster_ptime$root_cluster)

## ---- results='asis'----------------------------------------------------------
cluster_predecessors <- GetPredecessors(cluster_ptime$cluster_mst, cluster_ptime$root_cluster)
cluster_dtree <- GetDominatorTree(cluster_predecessors, cluster_ptime$graph_cluster)
PlotLineage(cluster_dtree)

## ---- results='asis'----------------------------------------------------------
pseudotime <- low_dim_mapping$dist_graph[root_cell,]

# plot pseudotime
FeatureScatterPlot(flat_embedding = low_dim_mapping$flat_embedding,
                         feature = pseudotime,
                         title = "Pseudotime Labeling",
                         subtitle = "t-SNE Embedding",
                         featurename = "Pseudotime Distance")

## ---- results='asis'----------------------------------------------------------
gene_index <- which(gene_names == 'Krt14')
data_gene <- logdata[gene_index,]

# plot features
FeatureScatterPlot(flat_embedding = low_dim_mapping$flat_embedding,
                    feature = data_gene,
                    title = "Krt14 Expression",
                    subtitle = "t-SNE Embedding",
                    featurename = "Log Expression")

## ---- results='asis'----------------------------------------------------------
gene_index <- which(gene_names == 'Krt10')
data_gene <- logdata[gene_index,]

# plot features
FeatureScatterPlot(flat_embedding = low_dim_mapping$flat_embedding,
                    feature = data_gene,
                    title = "Krt10 Expression",
                    subtitle = "t-SNE Embedding",
                    featurename = "Log Expression")

## ---- results='asis'----------------------------------------------------------
gene_index <- which(gene_names == 'Lor')
data_gene <- logdata[gene_index,]

# plot features
FeatureScatterPlot(flat_embedding = low_dim_mapping$flat_embedding,
                    feature = data_gene,
                    title = "Lor Expression",
                    subtitle = "t-SNE Embedding",
                    featurename = "Log Expression")

## ---- results='asis'----------------------------------------------------------
  ViolinPlotExpression(data = logdata,
                       gene_names = gene_names,
                       labels = labels,
                       gene_name = "Krt14")

## ---- results='asis'----------------------------------------------------------
  ViolinPlotExpression(data = logdata,
                       gene_names = gene_names,
                       labels = labels,
                       gene_name = "Krt10")

## ---- results='asis'----------------------------------------------------------
  ViolinPlotExpression(data = logdata,
                       gene_names = gene_names,
                       labels = labels,
                       gene_name = "Lor")

## ---- warning=FALSE-----------------------------------------------------------
library(knitr)
library(kableExtra)

lig_rec_path <- system.file("extdata", "tgfb_lig_rec.tsv", package = "RSoptSC")
rec_target_path <- system.file("extdata", "tgfb_rec_target_both.tsv", package = "RSoptSC")
pathway <- ImportPathway(lig_table_path = lig_rec_path,
                         rec_table_path = rec_target_path,
                         data = logdata,
                         gene_names = gene_names)



k = pathway$pathway %>% kable()

## ---- warning=FALSE-----------------------------------------------------------
library(knitr)
library(kableExtra)

lig_rec_path <- system.file("extdata", "tgfb_lig_rec.tsv", package = "RSoptSC")
rec_target_path <- system.file("extdata", "tgfb_rec_target_both.tsv", package = "RSoptSC")
pathway <- ImportPathway(lig_table_path = lig_rec_path,
                         rec_table_path = rec_target_path,
                         data = logdata,
                         gene_names = gene_names)



k = pathway$pathway %>% kable()
kable_styling(kable_input = k) %>% scroll_box(height = "500px", width = "300px")

## ---- results='hide', warning=FALSE,message=FALSE,error=FALSE-----------------
  datamat = as.matrix(logdata); rownames(datamat) = tolower(rownames(datamat)); colnames(datamat) = tolower(colnames(datamat))
  pathway$pathway_removed$receptor = tolower(pathway$pathway_removed$receptor)
  pathway$pathway_removed$ligand = tolower(pathway$pathway_removed$ligand)
  pathway$pathway_removed$target = tolower(pathway$pathway_removed$target)
  names(labels) = tolower(names(labels))
  
  Pmats <- GetSignalingPartners(datamat,labels,pathway)

## -----------------------------------------------------------------------------
SigPlot(Pmats$P_tot,labels)

## -----------------------------------------------------------------------------
  cluster_P <- ClusterSig(Pmats,
                          cluster_labels = labels)
  SigPlot_Cluster(cluster_P$P_tot,
          c(1:n_clusters))

## ---- results='asis', warning=FALSE, message= FALSE---------------------------
  gene_list = c('Tgfb1', 'Tgfb2', 
                'Tgfbr1', 'Tgfbr2',
                'Zeb2','Smad2','Wnt4','Wnt11','Bmp7','Sox9','Notch1')

  PlotClusterExpression(data = logdata,
                        cluster_labels = labels, 
                        markers = gene_list)

